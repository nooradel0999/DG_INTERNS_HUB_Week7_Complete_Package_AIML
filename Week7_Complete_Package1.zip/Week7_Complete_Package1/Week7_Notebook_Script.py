# Week 7 – K-Means Clustering (Notebook Script)
# Run in Jupyter / Google Colab

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler

# Load dataset
df = pd.read_csv('Mall_Customers_Clustering.csv')

# Preprocessing
X = df[['Annual Income (k$)', 'Spending Score (1-100)']]
scaler = StandardScaler()
Xs = scaler.fit_transform(X)

# Elbow Method
wcss = []
for k in range(2, 11):
    wcss.append(KMeans(n_clusters=k, n_init=10, random_state=42).fit(Xs).inertia_)
plt.plot(range(2,11), wcss, marker='o')
plt.title('Elbow Method')
plt.xlabel('K'); plt.ylabel('WCSS')
plt.show()

# K-Means K=5
kmeans = KMeans(n_clusters=5, n_init=10, random_state=42)
df['Cluster'] = kmeans.fit_predict(Xs)

# Visualization
plt.scatter(df['Annual Income (k$)'], df['Spending Score (1-100)'], c=df['Cluster'], cmap='viridis')
plt.title('K-Means Clusters')
plt.xlabel('Annual Income (k$)'); plt.ylabel('Spending Score (1-100)')
plt.show()

# DBSCAN
dbscan = DBSCAN(eps=0.55, min_samples=5)
df['DBSCAN'] = dbscan.fit_predict(Xs)
